<?php

	$con = mysqli_connect('localhost','root','','obms');

	if($con == false)
	{
		echo "Connection Failed.";
		
	}
	else{
		
		echo "";
	}
?>