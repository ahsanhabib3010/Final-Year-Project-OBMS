	<?php

	$con = mysqli_connect('localhost','root','','obms');

	if($con == false)
	{
		echo "connection is not done";
		
	}
	else{
		
		echo "";
	}
?>